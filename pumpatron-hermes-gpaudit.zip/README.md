# Pumpatron Hermes

Pumpatron Hermes is a realtime social-signal pipeline built around Hermes profiles.

## Fast Path

notification_events.jsonl / social_events.jsonl
-> fast_filter.py
-> pumpatron-hotdesk
-> Telegram-ready human review packet

## Active Runtime Components

- pumpatron-social-ingestor: collects public social records.
- pumpatron-fast-filter: deterministic local scoring and safety prefilter.
- pumpatron-hotdesk: single fast-path agent for hot/watch/reject triage and packet generation.
- pumpatron-archivist: async decision records.
- pumpatron-monitor: async monitoring.

## Runtime State

Runtime files are intentionally gitignored:

- pumpatron/data
- pumpatron/state
- pumpatron/logs
- pumpatron/packets
- pumpatron/evidence

Useful environment variables:

- PUMPATRON_BASE: runtime root, default /home/hermes/pumpatron
- PUMPATRON_HOT_MAX_AGE_MIN: default 30
- PUMPATRON_WATCH_MAX_AGE_MIN: default 180
- PUMPATRON_HOT_SCORE_MIN: default 70
- PUMPATRON_WATCH_SCORE_MIN: default 35
- PUMPATRON_ALLOW_WATCH: set to 1 only when you want the runner to send watch items to hotdesk

## Operations

The fast path runner expects Linux `flock`, `python3`, and the `pumpatron-hotdesk` command on PATH.

Example systemd units live in `pumpatron/systemd`:

- pumpatron-fast-path.service
- pumpatron-fast-path.timer

## Legacy / Audit Roles

The older multi-agent roles remain documented for audit and fallback, but they are no longer in the realtime critical path.

## Safety Boundary

This repository intentionally excludes secrets, wallet keys, sessions, cookies, browser profiles, logs, runtime databases, evidence files, and automated launch/signing code.
